"""Main application window (GTK4).

Builds the menubar and hamburger menus, hosts the editor and the status bar,
handles all document lifecycle (new/open/reopen/save/convert/quick view),
edit and formatting operations, theme/font persistence, the table-of-contents
generator, and the quick-view windows.
"""

from __future__ import annotations

import contextlib
import re
import urllib.request
import webbrowser
from pathlib import Path
from typing import TYPE_CHECKING

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("GtkSource", "5")

from gi.repository import Gdk, Gio, GLib, Gtk, GtkSource, Pango

if TYPE_CHECKING:
    from mark_editor.viewer import QuickViewWindow

from mark_editor.constants import (
    APP_NAME,
    EMOJIS,
    LANGUAGE_CODES,
    LANGUAGE_TAGS,
    RELEASE,
    SPECIAL_SIGNS,
    THEMES,
    VERSION,
)
from mark_editor.dialogs import (
    AboutDialog,
    ChoiceDialog,
    DateTimeDialog,
    DefinitionListDialog,
    FindDialog,
    FootnoteDialog,
    FuriganaDialog,
    HeaderLinkDialog,
    OrderedListDialog,
    ReplaceDialog,
    TableAlignDialog,
    TableDialog,
    TableRowDialog,
    TOCDialog,
    TodoListDialog,
    YAMLFrontMatterDialog,
    ask_string,
    show_message,
)
from mark_editor.editor import Editor
from mark_editor.helpers import (
    add_heading_ids,
    add_toc,
    cleanup_temp_html,
    cleanup_temp_md,
    clear_pending_text,
    ensure_cache_dir,
    load_font,
    load_temp_md,
    load_theme,
    md_to_html,
    md_to_pdf,
    md_to_plain,
    regenerate_toc,
    remove_toc,
    save_font,
    save_temp_html,
    save_temp_md,
    save_theme,
)


def _strip_heading_marker(text: str) -> str:
    """Remove a leading Markdown heading marker (``#`` run) from *text*."""
    return re.sub(r"^#{1,6}\s*", "", text)


_TABLE_ALIGN_RE = re.compile(r"^:?--+:?$")


def _strip_list_marker(text: str) -> str:
    """Remove a leading ordered/unordered/todo/quote list marker from *text*."""
    return re.sub(r"^(\* \[[ xX]\]\s*|(\d+\.|\*|-|>)\s*)", "", text)


def _make_filter_store(*filters: Gtk.FileFilter) -> Gio.ListStore:
    """Return a ListStore of the given file filters."""
    store = Gio.ListStore.new(Gtk.FileFilter)
    for f in filters:
        store.append(f)
    return store


def _make_md_filters() -> Gio.ListStore:
    """Return a ListStore of file filters (Markdown docs and all files)."""
    md_filter = Gtk.FileFilter()
    md_filter.set_name("Markdown files")
    md_filter.add_pattern("*.md")
    md_filter.add_pattern("*.markdown")
    all_filter = Gtk.FileFilter()
    all_filter.set_name("All files")
    all_filter.add_pattern("*")
    return _make_filter_store(md_filter, all_filter)


def _format_table_block(lines: list[str]) -> list[str]:
    """Reformat Markdown table *lines* with equal-width columns.

    Every row (header, separator and footer) is padded so that all columns
    share the same width and the right border is aligned.
    """
    rows = [line.split("|")[1:-1] for line in lines]
    ncols = max(len(r) for r in rows)
    widths = [max(len(r[c].strip()) for r in rows) for c in range(ncols)]
    out = []
    for r in rows:
        r = (r + [""] * ncols)[:ncols]
        cells = [r[c].strip().ljust(widths[c]) for c in range(ncols)]
        out.append("| " + " | ".join(cells) + " |")
    return out


def _file_signature(path: Path) -> tuple[int, int]:
    """Return the modification time and size used to detect disk changes."""
    stat = path.stat()
    return stat.st_mtime_ns, stat.st_size


class MarkEditorWindow(Gtk.ApplicationWindow):
    """The main Mark Editor application window."""

    def __init__(self, **kwargs) -> None:
        """Initialize the main editor window with saved settings."""
        super().__init__(**kwargs)
        self.set_title(APP_NAME)
        self.set_default_size(1100, 700)
        self.set_size_request(600, 400)

        self._theme_mode = load_theme()
        self._editor_font_family, self.editor_font_size = load_font()
        self.current_file: Path | None = None
        self.is_modified = False
        self._idle_update_pending = False
        self._quick_view_windows: list[QuickViewWindow] = []
        self._file_signature: tuple[int, int] | None = None
        self._external_check_id: int | None = None

        self._build_ui()
        self._restore_pending_text()
        self._update_title()
        self.connect("close-request", self._on_close_request)

    def _build_ui(self) -> None:
        """Assemble the main window layout: header bar, menu, editor, status bar."""
        header = Gtk.HeaderBar()
        menu_model = self._build_menu_model()
        menu_btn = Gtk.MenuButton()
        menu_btn.set_menu_model(menu_model)
        menu_btn.set_icon_name("open-menu-symbolic")
        menu_btn.set_tooltip_text("Menu")
        header.pack_end(menu_btn)
        self.set_titlebar(header)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        vbox.set_vexpand(True)
        vbox.set_hexpand(True)

        menubar_model = self._build_menubar_model()
        self._menubar = Gtk.PopoverMenuBar.new_from_model(menubar_model)
        self._menubar.set_hexpand(True)
        vbox.append(self._menubar)

        self._editor = Editor(mode=self._theme_mode)
        self._editor.set_vexpand(True)
        self._editor.set_hexpand(True)
        vbox.append(self._editor)

        self._status_label = Gtk.Label(label="Ln 1, Col 1")
        self._status_label.set_xalign(1.0)
        self._status_label.set_margin_start(12)
        self._status_label.set_margin_end(12)
        self._status_label.set_margin_top(4)
        self._status_label.set_margin_bottom(4)
        self._status_label.add_css_class("status-bar")
        vbox.append(self._status_label)

        self.set_child(vbox)

        self._editor.set_font_family(self._editor_font_family)
        self._editor.set_font_size(self.editor_font_size)

        if self._theme_mode == "dark":
            self._status_label.add_css_class("dark")

        buf = self._editor.get_buffer()
        buf.connect("modified-changed", self._on_editor_modified)
        buf.connect("changed", self._on_editor_changed)

    def _build_menubar_model(self) -> Gio.Menu:
        """Return the full menu-bar model (File/Edit/Format/Paragraph/View/Help)."""
        menubar = Gio.Menu()

        file_menu = Gio.Menu()
        file_menu.append("New File", "app.new")
        file_menu.append("Open...", "app.open")
        file_menu.append("Reopen", "app.reopen")
        file_menu.append("Save", "app.save")
        file_menu.append("Save As...", "app.save-as")
        file_menu.append("Convert...", "app.convert")
        file_menu.append("Quit", "app.quit")
        menubar.append_submenu("File", file_menu)

        edit_menu = Gio.Menu()
        edit_menu.append("Undo", "app.undo")
        edit_menu.append("Redo", "app.redo")
        edit_menu.append("Cut", "app.cut")
        edit_menu.append("Copy", "app.copy")
        edit_menu.append("Paste", "app.paste")
        edit_menu.append("Find...", "app.find")
        edit_menu.append("Replace...", "app.replace")
        edit_menu.append("Select All", "app.select-all")
        edit_menu.append("Remove Selection", "app.remove-selection")
        edit_menu.append("Line Up", "app.line-up")
        edit_menu.append("Line Down", "app.line-down")
        edit_menu.append("Delete Line", "app.delete-line")
        menubar.append_submenu("Edit", edit_menu)

        fmt_menu = Gio.Menu()
        fmt_menu.append("Bold", "app.bold")
        fmt_menu.append("Italic", "app.italic")
        fmt_menu.append("Underline", "app.underline")
        fmt_menu.append("Strikethrough", "app.strikethrough")
        fmt_menu.append("Superscript", "app.superscript")
        fmt_menu.append("Subscript", "app.subscript")
        fmt_menu.append("Inline Code", "app.inline-code")
        fmt_menu.append("Mark", "app.mark")
        fmt_menu.append("Hyperlink...", "app.hyperlink")
        fmt_menu.append("Header ID...", "app.header-id")
        fmt_menu.append("Header Link...", "app.header-link")
        fmt_menu.append("TOC...", "app.toc")
        fmt_menu.append("Footnote...", "app.footnote")
        fmt_menu.append("Date and Time...", "app.date-time")
        fmt_menu.append("Language Marker...", "app.language-marker")
        fmt_menu.append("Language Wrapping...", "app.language-wrapping")

        lang_codes_menu = Gio.Menu()
        for code, desc in LANGUAGE_CODES:
            lang_codes_menu.append(f"{code} {desc}", f"app.insert-lang-{code}")
        fmt_menu.append_submenu("Language Codes", lang_codes_menu)

        fmt_menu.append("Furigana...", "app.furigana")

        emoji_menu = Gio.Menu()
        for emoji in EMOJIS:
            emoji_menu.append(f":{emoji}:", f"app.insert-emoji-{emoji}")
        fmt_menu.append_submenu("Emoji Shortcodes", emoji_menu)

        signs_menu = Gio.Menu()
        for name, sign in SPECIAL_SIGNS:
            safe_name = name.replace(" ", "-")
            signs_menu.append(f"{sign} {name}", f"app.insert-sign-{safe_name}")
        fmt_menu.append_submenu("Special Signs", signs_menu)

        fmt_menu.append("Special Mark", "app.special-mark")

        fmt_menu.append("Clear Formatting", "app.clear-formatting")

        menubar.append_submenu("Format", fmt_menu)

        para_menu = Gio.Menu()
        for level in range(1, 7):
            para_menu.append(f"Heading {level}", f"app.heading-{level}")
        para_menu.append("Paragraph", "app.paragraph")
        para_menu.append("Ordered List...", "app.ordered-list")
        para_menu.append("Unordered List", "app.unordered-list")
        para_menu.append("Todo List...", "app.todo-list")
        para_menu.append("Definition List...", "app.definition-list")
        para_menu.append("Code Block...", "app.code-block")
        para_menu.append("Blockquote", "app.blockquote")
        para_menu.append("Table...", "app.table")
        para_menu.append("Add Table Row...", "app.add-table-row")
        para_menu.append("Table Alignment...", "app.align-table")
        para_menu.append("Balance Table", "app.balance-table")
        para_menu.append("Image...", "app.image")
        para_menu.append("Horizontal Rule", "app.horizontal-rule")
        para_menu.append("Comment...", "app.comment")
        para_menu.append("YAML Front Matter...", "app.yaml-front-matter")
        para_menu.append("Line Break", "app.line-break")
        para_menu.append("Add Indent", "app.add-indent")
        para_menu.append("Remove Indent", "app.remove-indent")
        menubar.append_submenu("Paragraph", para_menu)

        view_menu = Gio.Menu()
        view_menu.append("Toggle Theme", "app.toggle-theme")
        view_menu.append("Editor Font...", "app.editor-font")
        view_menu.append("Zoom In", "app.zoom-in")
        view_menu.append("Zoom Out", "app.zoom-out")
        view_menu.append("Quick View", "app.quick-view")
        menubar.append_submenu("View", view_menu)

        help_menu = Gio.Menu()
        help_menu.append("Markdown Guide", "app.help-markdown-guide")
        help_menu.append("Full Markdown Functionality Reference", "app.help-md-ref")
        help_menu.append("Keyboard Shortcuts Cheat Sheet", "app.help-cheatsheet")
        help_menu.append("About Editor", "app.help-about")
        menubar.append_submenu("Help", help_menu)

        return menubar

    def _build_menu_model(self) -> Gio.Menu:
        """Return the hamburger menu model (compact subset of the menu bar)."""
        menu = Gio.Menu()
        section = Gio.Menu()
        section.append("New File", "app.new")
        section.append("Open...", "app.open")
        section.append("Save", "app.save")
        section.append("Save As...", "app.save-as")
        section.append("Convert...", "app.convert")
        menu.append_section(None, section)

        section2 = Gio.Menu()
        section2.append("Find...", "app.find")
        section2.append("Replace...", "app.replace")
        menu.append_section(None, section2)

        section3 = Gio.Menu()
        section3.append("Toggle Theme", "app.toggle-theme")
        section3.append("About Editor", "app.help-about")
        menu.append_section(None, section3)
        return menu

    def _update_title(self) -> None:
        """Refresh the title to reflect the file name and modification state."""
        symbol = "*" if self.is_modified else ""
        name = self.current_file.name if self.current_file else "New File"
        self.set_title(f"{APP_NAME} - {symbol}{name}")

    def _update_status(self) -> None:
        """Update the status-bar label with the current cursor line and column."""
        try:
            cursor = self._editor.get_cursor_iter()
            line = cursor.get_line() + 1
            col = cursor.get_line_offset() + 1
            self._status_label.set_text(f"Ln {line}, Col {col}")
        except Exception:
            pass

    def _on_editor_modified(self, buf: GtkSource.Buffer) -> None:
        """Handle the buffer's modified-changed signal."""
        if not buf.get_modified():
            return
        self.is_modified = True
        self._update_title()

    def _on_editor_changed(self, buf: GtkSource.Buffer) -> None:
        """Schedule an idle update when the buffer content changes."""
        if not self._idle_update_pending:
            self._idle_update_pending = True
            GLib.idle_add(self._do_editor_update)

    def _do_editor_update(self) -> bool:
        """Perform the idle callback: update status bar and auto-save temp file."""
        self._idle_update_pending = False
        self._update_status()
        text = self._editor.get_text()
        save_temp_md(text, self.current_file)
        return False

    def _on_new(self) -> None:
        """Clear the editor and reset to an empty untitled document."""
        self._editor.clear()
        self.current_file = None
        self.is_modified = False
        self._file_signature = None
        self._stop_external_check()
        self._update_title()
        self._editor.focus()

    def _on_open(self) -> None:
        """Open a file-chooser dialog to load a Markdown file."""
        dialog = Gtk.FileDialog()
        dialog.set_title("Open file")
        dialog.set_filters(_make_md_filters())
        dialog.open(self, None, self._on_open_response)

    def _on_open_response(self, dialog, result) -> None:
        """Handle the result of the Open file dialog."""
        try:
            file = dialog.open_finish(result)
        except GLib.Error:
            return
        self.load_file(Path(file.get_path()))

    def load_file(self, path: Path) -> None:
        """Load *path* into the editor, cleaning up the previous file's temps."""
        try:
            text = path.read_text(encoding="utf-8")
        except Exception as exc:
            show_message(self, "Open file", str(exc), "error")
            return
        old_file = self.current_file
        self._editor.set_text(text)
        self.current_file = path
        if old_file:
            cleanup_temp_md(old_file.parent)
        self.is_modified = False
        self._file_signature = _file_signature(path)
        self._start_external_check()
        self._update_title()

    def _start_external_check(self) -> None:
        """Start watching the current file for changes made outside the editor."""
        if self._external_check_id is None:
            self._external_check_id = GLib.timeout_add_seconds(
                1, self._check_external_change
            )

    def _stop_external_check(self) -> None:
        """Stop watching the current file for external changes."""
        if self._external_check_id is not None:
            GLib.source_remove(self._external_check_id)
            self._external_check_id = None

    def _check_external_change(self) -> bool:
        """Reload the current file when another program changes it on disk."""
        if self.current_file is None:
            self._external_check_id = None
            return False
        try:
            signature = _file_signature(self.current_file)
        except OSError:
            self._external_check_id = None
            return False
        if signature != self._file_signature:
            self.load_file(self.current_file)
        return True

    def _on_reopen(self) -> None:
        """Reload the current file from disk, discarding unsaved changes."""
        if not self.current_file:
            return
        try:
            text = self.current_file.read_text(encoding="utf-8")
        except Exception as exc:
            show_message(self, "Reopen file", str(exc), "error")
            return
        self._editor.set_text(text)
        self.is_modified = False
        self._file_signature = _file_signature(self.current_file)
        self._start_external_check()
        self._update_title()
        cleanup_temp_md(self.current_file.parent)
        show_message(self, "Reopen file", "File reopened!")

    def _on_save(self) -> bool:
        """Save to the current file, or fall back to Save As if untitled."""
        if self.current_file:
            self._save_to(self.current_file)
            return True
        return self._on_save_as()

    def _save_to(self, path: Path) -> None:
        """Write the editor content to *path* and update modification state."""
        try:
            text = self._editor.get_text()
            path.write_text(text, encoding="utf-8")
            self.current_file = path
            self.is_modified = False
            self._editor.set_modified(False)
            self._file_signature = _file_signature(path)
            self._start_external_check()
            self._update_title()
        except Exception as exc:
            show_message(self, "Save file", str(exc), "error")
            return
        show_message(self, "Save file", "File saved!")

    def _on_save_as(self) -> bool:
        """Open a file-chooser dialog to save under a new name."""
        dialog = Gtk.FileDialog()
        dialog.set_title("Save As")
        dialog.set_filters(_make_md_filters())

        initial = self.current_file.name if self.current_file else "untitled.md"
        dialog.set_initial_name(initial)
        dialog.save(self, None, self._on_save_as_response)
        return True

    def _on_save_as_response(self, dialog, result) -> None:
        """Handle the result of the Save As file dialog."""
        try:
            file = dialog.save_finish(result)
        except GLib.Error:
            return
        path = Path(file.get_path())
        if not path.suffix:
            path = path.with_suffix(".md")
        self._save_to(path)

    def _on_convert(self) -> None:
        """Show the format chooser then a file dialog for export."""
        formats = [
            "HTML5 file (.html)",
            "HTML5 file (landscape) (.html)",
            "Plain text file (.txt)",
            "PDF file portrait (.pdf)",
            "PDF file landscape (.pdf)",
        ]
        dlg = ChoiceDialog(
            prompt="Choose the target format:", items=formats, initial=formats[0]
        )
        dlg.connect("closed", lambda _: self._convert_after_choice(dlg.result, formats))
        dlg.present()

    def _convert_after_choice(self, choice: str | None, formats: list[str]) -> None:
        """Show the file-save dialog after the user picks an export format."""
        if not choice:
            return
        if choice.startswith("HTML5"):
            ext = ".html"
        elif choice.startswith("Plain"):
            ext = ".txt"
        else:
            ext = ".pdf"
        page_layout = "landscape" if "landscape" in choice else "portrait"

        f = Gtk.FileFilter()
        f.set_name(
            f"{'HTML5' if ext == '.html' else 'Text' if ext == '.txt' else 'PDF'} files"
        )
        f.add_pattern(f"*{ext}")
        filters = _make_filter_store(f)

        base = self.current_file.name if self.current_file else "document"
        if base.endswith((".md", ".markdown")):
            base = base.rsplit(".", 1)[0]

        dialog = Gtk.FileDialog()
        dialog.set_title("Convert")
        dialog.set_initial_name(base + ext)
        dialog.set_filters(filters)
        dialog.save(
            self,
            None,
            lambda d, r: self._perform_convert_response(d, r, ext, page_layout),
        )

    def _perform_convert_response(
        self, dialog, result, ext: str, page_layout: str = "portrait"
    ) -> None:
        """Handle the result of the Convert file dialog and perform the export."""
        try:
            file = dialog.save_finish(result)
        except GLib.Error:
            return
        path = Path(file.get_path())
        try:
            content = self._editor.get_text()
            if ext == ".html":
                html = md_to_html(content, page_layout=page_layout)
                path.write_text(html, encoding="utf-8")
            elif ext == ".txt":
                path.write_text(md_to_plain(content), encoding="utf-8")
            else:
                md_to_pdf(
                    content,
                    str(path),
                    source_file=self.current_file,
                    page_layout=page_layout,
                )
        except Exception as exc:
            show_message(self, "Convert", str(exc), "error")
            return
        show_message(self, "Convert", "Conversion complete!")

    def _cleanup_temp_files(self) -> None:
        """Delete temporary files and the cached unsaved-buffer file."""
        if self.current_file:
            cleanup_temp_md(self.current_file.parent)
            cleanup_temp_html(self.current_file.parent)
        else:
            cleanup_temp_md(ensure_cache_dir())
            cleanup_temp_html(ensure_cache_dir())
        clear_pending_text()

    def _close_quick_view_windows(self) -> None:
        """Close all open quick-view windows (deleting their ~*.html files)."""
        for window in list(self._quick_view_windows):
            window.close()

    def _on_quick_view_window_closed(self, window: QuickViewWindow) -> None:
        """Forget a quick-view window once it is closed or destroyed."""
        with contextlib.suppress(ValueError):
            self._quick_view_windows.remove(window)

    def _on_close_request(self, _widget) -> bool:
        """Clean up temp files when the editor window is closed."""
        self._stop_external_check()
        self._close_quick_view_windows()
        self._cleanup_temp_files()
        return False

    def _on_quit(self) -> None:
        """Clean up temp files and close the application window."""
        self._on_close_request(None)
        self.close()

    def _on_undo(self) -> None:
        """Undo the last editing action."""
        self._editor.undo()

    def _on_redo(self) -> None:
        """Redo the last undone editing action."""
        self._editor.redo()

    def _copy_selection(self) -> bool:
        """Copy the current selection to the clipboard. Returns True if copied."""
        clipboard = Gdk.Display.get_default().get_clipboard()
        text = self._editor.get_selected_text()
        if text:
            clipboard.set(text)
            return True
        return False

    def _on_cut(self) -> None:
        """Cut the selection to the clipboard."""
        if self._copy_selection():
            self._editor.delete_selection()

    def _on_copy(self) -> None:
        """Copy the selection to the clipboard."""
        self._copy_selection()

    def _on_paste(self) -> None:
        """Paste text from the clipboard asynchronously."""
        clipboard = Gdk.Display.get_default().get_clipboard()
        clipboard.read_text_async(None, self._on_paste_text)

    def _on_paste_text(self, clipboard, result) -> None:
        """Handle the asynchronous clipboard text read result."""
        try:
            text = clipboard.read_text_finish(result)
        except GLib.Error:
            return
        if text:
            self._editor.replace_selection(text)

    def _on_select_all(self) -> None:
        """Select the entire document."""
        self._editor.select_all()

    def _on_remove_selection(self) -> None:
        """Deselect the current selection without modifying the text."""
        buf = self._editor.get_buffer()
        buf.place_cursor(buf.get_iter_at_mark(buf.get_insert()))
        self._editor.focus()

    def _on_line_up(self) -> None:
        """Move the current line or selection block one line up."""
        bounds = self._editor.get_selection_bounds()
        if bounds:
            start_line, end_line = self._get_selection_line_range(bounds)
            if start_line <= 1:
                return
            self._move_lines(start_line, end_line, -1)
            self._select_lines(start_line - 1, end_line - 1)
        else:
            line = self._editor.get_current_line_number()
            if line <= 1:
                return
            self._move_lines(line, line, -1)

    def _on_line_down(self) -> None:
        """Move the current line or selection block one line down."""
        bounds = self._editor.get_selection_bounds()
        total = self._editor.get_line_count()
        if bounds:
            start_line, end_line = self._get_selection_line_range(bounds)
            if end_line >= total:
                return
            self._move_lines(start_line, end_line, 1)
            self._select_lines(start_line + 1, end_line + 1)
        else:
            line = self._editor.get_current_line_number()
            if line >= total:
                return
            self._move_lines(line, line, 1)

    def _get_selection_line_range(
        self, bounds: tuple[Gtk.TextIter, Gtk.TextIter]
    ) -> tuple[int, int]:
        """Return the (start_line, end_line) range covered by a selection (1-based).

        A selection ending at the start of a line does not include that line.
        """
        start, end = bounds
        start_line = start.get_line()
        end_line = end.get_line()
        if end.get_line_offset() == 0 and end_line > start_line:
            end_line -= 1
        return start_line + 1, end_line + 1

    def _move_lines(self, start_line: int, end_line: int, delta: int) -> None:
        """Move *start_line*..*end_line* up (delta=-1) or down (delta=+1)."""
        block = [self._editor.get_line_text(i) for i in range(start_line, end_line + 1)]
        buf = self._editor.get_buffer()
        buf.begin_user_action()
        if delta < 0:
            above = self._editor.get_line_text(start_line - 1)
            for i, text in enumerate(block):
                self._editor.replace_line(start_line - 1 + i, text)
            self._editor.replace_line(end_line, above)
        else:
            below = self._editor.get_line_text(end_line + 1)
            for i, text in enumerate(block):
                self._editor.replace_line(start_line + 1 + i, text)
            self._editor.replace_line(start_line, below)
        buf.end_user_action()

    def _select_lines(self, start_line: int, end_line: int) -> None:
        """Select the full lines *start_line*..*end_line* (1-based)."""
        buf = self._editor.get_buffer()
        _, start = buf.get_iter_at_line(start_line - 1)
        _, end = buf.get_iter_at_line(end_line)
        buf.select_range(start, end)

    def _on_delete_line(self) -> None:
        """Delete the entire line at the cursor position."""
        line = self._editor.get_current_line_number()
        buf = self._editor.get_buffer()
        total = buf.get_line_count()
        _, start = buf.get_iter_at_line(line - 1)
        if line < total:
            # Non-last line: end iterator sits at the start of the next line,
            # which includes the trailing '\n' of the current line.
            _, end = buf.get_iter_at_line(line)
        else:
            # Last line: advance to the very end of the buffer.
            end = buf.get_end_iter()
        buf.begin_user_action()
        buf.delete(start, end)
        buf.end_user_action()

    def _on_find(self) -> None:
        """Open the Find dialog."""
        dlg = FindDialog(self._editor)
        dlg.present()

    def _on_replace(self) -> None:
        """Open the Find & Replace dialog."""
        dlg = ReplaceDialog(self._editor)
        dlg.present()

    def _insert_text(self, text: str) -> None:
        """Insert *text* at the cursor and return focus to the editor."""
        self._editor.insert_at_cursor(text)
        self._editor.focus()

    def _wrap_selection(self, wrapper: str) -> None:
        """Wrap the selection in *wrapper* characters (e.g. ``**`` for bold).

        With no selection, insert a marker pair at the cursor instead.
        """
        self._editor.wrap_selection(wrapper)
        self._editor.focus()

    def _on_bold(self) -> None:
        """Wrap the selection in bold formatting (``**``)."""
        self._wrap_selection("**")

    def _on_italic(self) -> None:
        """Wrap the selection in italic formatting (``*``)."""
        self._wrap_selection("*")

    def _on_underline(self) -> None:
        """Wrap the selection in underline formatting (``^^``)."""
        self._wrap_selection("^^")

    def _on_strikethrough(self) -> None:
        """Wrap the selection in strikethrough formatting (``~~``)."""
        self._wrap_selection("~~")

    def _on_superscript(self) -> None:
        """Wrap the selection in superscript formatting (``^``)."""
        self._wrap_selection("^")

    def _on_subscript(self) -> None:
        """Wrap the selection in subscript formatting (``~``)."""
        self._wrap_selection("~")

    def _on_inline_code(self) -> None:
        """Wrap the selection in inline code formatting (`` ` ``)."""
        self._wrap_selection("`")

    def _on_mark(self) -> None:
        """Wrap the selection in mark (highlight) formatting (``==``)."""
        self._wrap_selection("==")

    def _on_header_id(self) -> None:
        """Prompt for a header ID and append it to the current heading line."""
        line_num = self._editor.get_current_line_number()
        line = self._editor.get_line_text(line_num)

        def on_hid(hid):
            """Handle header ID input."""
            if not hid:
                return
            hid = hid.strip().lstrip("#")
            if line.strip():
                self._editor.replace_line(line_num, f"{line.rstrip()} {{#{hid}}}")
            else:
                self._editor.replace_line(line_num, f"# {{#{hid}}}")

        ask_string(self, "Enter the header ID (without #):", "Header ID", on_hid)

    def _on_header_link(self) -> None:
        """Open the Header Link dialog to insert a heading cross-reference."""
        dlg = HeaderLinkDialog(self._insert_text)
        dlg.present()

    def _on_toc(self) -> None:
        """Open the TOC dialog to add, regenerate, remove or number a TOC."""

        def on_operation(op: int, heading: str) -> None:
            """Apply the chosen *op* with *heading* and report the result."""
            text = self._editor.get_text()
            message = "TOC created!"
            if op == 0:  # Add TOC
                text = add_toc(text, heading)
            elif op == 1:  # Regenerate existing TOC
                text = regenerate_toc(text, heading)
                message = "TOC regenerated!"
            elif op == 3:  # Add Header IDs only
                text = add_heading_ids(text)
                message = "Header IDs added!"
            else:  # Remove existing TOC
                text = remove_toc(text)
                message = "TOC removed!"
            self._editor.set_text(text)
            self._editor.focus()
            show_message(self, "Table of Content", message)

        dlg = TOCDialog(on_operation)
        dlg.present()

    def _on_hyperlink(self) -> None:
        """Prompt for URL and text, then insert a Markdown hyperlink."""
        selected = self._editor.get_selected_text()

        def on_url(url):
            """Handle URL input."""
            if not url:
                return

            def on_text(text):
                """Handle link text input."""
                if selected:
                    self._editor.replace_selection(f"[{text}]({url})")
                else:
                    self._editor.insert_at_cursor(f"[{text}]({url})")
                self._editor.focus()

            if selected:
                on_text(selected)
            else:
                ask_string(self, "Enter the link text:", "Hyperlink", on_text)

        ask_string(self, "Enter the URL:", "Hyperlink", on_url)

    def _on_footnote(self) -> None:
        """Open the Footnote dialog to insert a reference and optional definition."""

        def callback(ref, definition):
            """Handle footnote input."""
            self._editor.insert_at_cursor(f"[^{ref}]")
            if definition:
                buf = self._editor.get_buffer()
                end = buf.get_end_iter()
                buf.insert(end, f"\n\n[^{ref}]: {definition}")
            self._editor.focus()

        dlg = FootnoteDialog(callback)
        dlg.present()

    def _on_language_marker(self) -> None:
        """Prepend a language marker tag (e.g. ``:de``) to the current line."""

        def on_lang(lang):
            """Handle language marker input."""
            if not lang:
                return
            lang = lang.strip()
            line_num = self._editor.get_current_line_number()
            line = self._editor.get_line_text(line_num)
            self._editor.replace_line(line_num, f"{{:{lang}}} {line}")
            self._editor.focus()

        ask_string(
            self,
            "or enter a valid BCP 47 tag:",
            "Language Marker",
            on_lang,
            options=LANGUAGE_TAGS,
        )

    def _on_language_wrapping(self) -> None:
        """Wrap the selection with a language tag pair (e.g. ``{:fr}…{:}``)."""

        def on_lang(lang):
            """Handle language wrapping input."""
            if not lang:
                return
            lang = lang.strip()
            selected = self._editor.get_selected_text()
            if selected:
                self._editor.replace_selection(f"{{:{lang}}}{selected}{{:}}")
            else:
                self._editor.insert_at_cursor(f"{{:{lang}}}{{:}}")
            self._editor.focus()

        ask_string(
            self,
            "or enter a valid BCP 47 tag:",
            "Language Wrapping",
            on_lang,
            options=LANGUAGE_TAGS,
        )

    def _on_furigana(self) -> None:
        """Open the Furigana dialog to add a ruby annotation."""
        dlg = FuriganaDialog(self._editor)
        dlg.present()

    def _on_date_time(self) -> None:
        """Open the Date & Time dialog to insert a formatted timestamp."""
        dlg = DateTimeDialog(self._insert_text)
        dlg.present()

    def _on_special_mark(self) -> None:
        """Insert a backslash escape character."""
        self._editor.insert_at_cursor("\\")
        self._editor.focus()

    def _on_clear_formatting(self) -> None:
        """Strip all Markdown syntax from the document, producing plain text."""
        text = self._editor.get_text()
        cleaned = md_to_plain(text)
        self._editor.set_text(cleaned)

    def _get_current_line_text(self) -> str:
        """Return the text of the line at the cursor (without the trailing newline)."""
        return self._editor.get_line_text(self._editor.get_current_line_number())

    def _replace_current_line(self, new_text: str) -> None:
        """Replace the content of the line at the cursor with *new_text*."""
        self._editor.replace_line(self._editor.get_current_line_number(), new_text)

    def _add_blank_line_before_if_needed(self) -> None:
        """Insert a blank line if the previous line is non-empty."""
        line = self._editor.get_current_line_number()
        if line <= 1:
            return
        prev = self._editor.get_line_text(line - 1)
        if prev.strip():
            buf = self._editor.get_buffer()
            _, insert_pos = buf.get_iter_at_line(line - 1)
            buf.begin_user_action()
            buf.insert(insert_pos, "\n")
            buf.end_user_action()

    def _prev_line_is_list_item(self) -> bool:
        """Return True when the previous line begins a list marker."""
        line = self._editor.get_current_line_number()
        if line <= 1:
            return False
        prev = self._editor.get_line_text(line - 1)
        return bool(re.match(r"^(\d+\.|\*|-)\s", prev))

    def _on_heading(self, level: int) -> None:
        """Set the current line as a heading of the given *level* (1-6)."""
        text = self._get_current_line_text()
        text = _strip_heading_marker(text)
        self._add_blank_line_before_if_needed()
        self._replace_current_line(f"{'#' * level} {text}")

    def _on_paragraph(self) -> None:
        """Convert the current heading line to a normal paragraph."""
        text = self._get_current_line_text()
        text = _strip_heading_marker(text)
        self._add_blank_line_before_if_needed()
        self._replace_current_line(text)

    def _convert_to_list_item(self, marker: str) -> None:
        """Convert the current line into a list item prefixed by *marker*."""
        text = self._get_current_line_text()
        text = _strip_list_marker(text)
        if not self._prev_line_is_list_item():
            self._add_blank_line_before_if_needed()
        self._replace_current_line(f"{marker} {text}")

    def _on_ordered_list(self) -> None:
        """Turn the current line into an ordered-list item with a chosen number."""

        def on_number(number: int) -> None:
            """Apply the chosen item *number* to the current line."""
            self._convert_to_list_item(f"{number}.")
            self._editor.focus()

        dlg = OrderedListDialog(on_number)
        dlg.present()

    def _on_unordered_list(self) -> None:
        """Convert the current line to an unordered-list item (``- …``)."""
        self._convert_to_list_item("-")

    def _on_todo_list(self) -> None:
        """Add/update a ``[ ]`` / ``[x]`` marker on the current line.

        Applies to a list item or an already-marked todo line.
        """

        def on_checked(checked: bool) -> None:
            """Apply the done state as a todo marker to the current line."""
            state = "x" if checked else " "
            text = self._get_current_line_text()
            m = re.match(r"^((?:\d+\.|\*|-)\s+)?(\[[ xX]\])\s+", text)
            if m:
                rest = text[m.end() :]
                self._replace_current_line(f"{m.group(1) or ''}[{state}] {rest}")
            else:
                m = re.match(r"^(\d+\.|\*|-)\s+", text)
                if m:
                    rest = text[m.end() :]
                    self._replace_current_line(f"{m.group(0)}[{state}] {rest}")
            self._editor.focus()

        dlg = TodoListDialog(on_checked)
        dlg.present()

    def _on_definition_list(self) -> None:
        """Open the Definition List dialog to insert a term/definition block."""
        dlg = DefinitionListDialog(self._insert_block)
        dlg.present()

    def _on_code_block(self) -> None:
        """Prompt for a language tag and add fences around the selection or line."""

        def on_lang(lang):
            """Handle code block language input."""
            lang = (lang or "").strip()
            selected = self._editor.get_selected_text()
            if selected:
                self._editor.replace_selection(f"```{lang}\n{selected}\n```")
                return
            text = self._get_current_line_text()
            self._add_blank_line_before_if_needed()
            self._replace_current_line(f"```{lang}\n{text}\n```")

        ask_string(
            self, "Enter the programming language (optional):", "Code Block", on_lang
        )

    def _on_blockquote(self) -> None:
        """Convert the current line to a blockquote (``> …``)."""
        self._convert_to_list_item(">")

    def _on_table(self) -> None:
        """Open the Table dialog to insert a Markdown table."""
        dlg = TableDialog(self._insert_block)
        dlg.present()

    def _on_add_table_row(self) -> None:
        """Insert a new table row below the current line with a chosen cell count."""

        def on_count(count: int) -> None:
            """Apply the chosen *count* as a pipe row on the next line."""
            row = "| " + " | ".join(["Cell"] * count) + " |"
            line = self._editor.get_current_line_number()
            buf = self._editor.get_buffer()
            _, end = buf.get_iter_at_line(line - 1)
            if not end.ends_line():
                end.forward_to_line_end()
            buf.begin_user_action()
            buf.insert(end, "\n" + row)
            buf.end_user_action()
            self._editor.focus()

        dlg = TableRowDialog(on_count)
        dlg.present()

    def _on_table_align(self) -> None:
        """Open the Table Alignment dialog for setting an alignment marker."""

        def on_align(marker: str) -> None:
            """Apply the chosen *marker* to the alignment cell or cursor."""
            self._apply_table_align(marker)

        dlg = TableAlignDialog(on_align)
        dlg.present()

    def _apply_table_align(self, marker: str) -> None:
        """Set the alignment cell at the cursor to *marker* or insert it."""
        if not self._set_alignment_value(marker):
            self._editor.replace_selection(marker)
        self._editor.focus()

    def _set_alignment_value(self, marker: str) -> bool:
        """Replace the alignment cell under the cursor; False when none found."""
        editor = self._editor
        buf = editor.get_buffer()
        line_no = editor.get_current_line_number()
        line = editor.get_line_text(line_no)
        col = editor.get_cursor_iter().get_line_offset()
        cells: list[tuple[int, int]] = []
        start = 0
        for index, char in enumerate(line):
            if char == "|":
                cells.append((start, index))
                start = index + 1
        cell = next(
            (
                (a, b)
                for a, b in cells
                if a <= col < b and _TABLE_ALIGN_RE.match(line[a:b].strip())
            ),
            None,
        )
        if cell is None:
            return False
        _, iter_start = buf.get_iter_at_line(line_no - 1)
        iter_start.forward_chars(cell[0])
        iter_end = iter_start.copy()
        iter_end.forward_chars(cell[1] - cell[0])
        buf.begin_user_action()
        buf.delete(iter_start, iter_end)
        buf.insert(iter_start, f" {marker} ", -1)
        buf.end_user_action()
        return True

    def _on_balance_table(self) -> None:
        """Reformat the table at the cursor with equal-width, aligned columns."""
        editor = self._editor
        buf = editor.get_buffer()
        line = editor.get_current_line_number()

        def is_table_row(n: int) -> bool:
            """Return True when line *n* looks like a Markdown table row."""
            return bool(re.match(r"^\s*\|.*\|\s*$", editor.get_line_text(n)))

        if not is_table_row(line):
            return
        top = line
        while top > 1 and is_table_row(top - 1):
            top -= 1
        bottom = line
        while bottom < editor.get_line_count() and is_table_row(bottom + 1):
            bottom += 1

        lines = [editor.get_line_text(n) for n in range(top, bottom + 1)]
        new_lines = _format_table_block(lines)
        if new_lines == lines:
            return
        _, start = buf.get_iter_at_line(top - 1)
        _, end = buf.get_iter_at_line(bottom)
        buf.begin_user_action()
        buf.delete(start, end)
        buf.insert(start, "\n".join(new_lines) + "\n", -1)
        buf.end_user_action()

    def _on_image(self) -> None:
        """Open a file chooser for an image, then prompt for alt text and title."""
        dialog = Gtk.FileDialog()
        dialog.set_title("Choose an image")
        f = Gtk.FileFilter()
        f.set_name("Images")
        for ext in ("*.png", "*.jpg", "*.jpeg", "*.gif", "*.svg", "*.webp"):
            f.add_pattern(ext)
        f2 = Gtk.FileFilter()
        f2.set_name("All files")
        f2.add_pattern("*")
        dialog.set_filters(_make_filter_store(f, f2))
        dialog.open(self, None, self._on_image_response)

    def _on_image_response(self, dialog, result) -> None:
        """Handle the result of the image file chooser dialog."""
        try:
            file = dialog.open_finish(result)
        except GLib.Error:
            return
        path = file.get_path()

        def on_alt(alt):
            """Handle alt text input."""
            alt = (alt or "").strip()

            def on_title(title):
                """Handle image title input."""
                title = (title or "").strip()
                if title:
                    markdown = f'![{alt}]({path} "{title}")'
                else:
                    markdown = f"![{alt}]({path})"
                self._add_blank_line_before_if_needed()
                self._insert_block(markdown)

            ask_string(
                self, "Enter an Optional title (or leave empty):", "Image", on_title
            )

        ask_string(self, "Enter the Alt text:", "Image", on_alt)

    def _on_line_break(self) -> None:
        """Insert a Markdown hard line break (two trailing spaces + newline)."""
        self._editor.insert_at_cursor("  \n")
        self._editor.focus()

    def _on_horizontal_rule(self) -> None:
        """Insert a horizontal rule (``***``)."""
        self._insert_block("***")

    def _line_range(self) -> tuple[int, int]:
        """Return the selected line range, or the current line (1-based)."""
        bounds = self._editor.get_selection_bounds()
        if bounds:
            return self._get_selection_line_range(bounds)
        line = self._editor.get_current_line_number()
        return line, line

    def _on_add_indent(self) -> None:
        """Indent the current line or all selected lines by two spaces."""
        start_line, end_line = self._line_range()
        buf = self._editor.get_buffer()
        buf.begin_user_action()
        for line in range(start_line, end_line + 1):
            _, pos = buf.get_iter_at_line(line - 1)
            buf.insert(pos, "  ")
        buf.end_user_action()

    def _on_remove_indent(self) -> None:
        """Remove up to two leading spaces from current line or all selected lines."""
        start_line, end_line = self._line_range()
        buf = self._editor.get_buffer()
        buf.begin_user_action()
        for line in range(start_line, end_line + 1):
            text = self._editor.get_line_text(line)
            if text.startswith("  "):
                self._editor.replace_line(line, text[2:])
            elif text.startswith(" "):
                self._editor.replace_line(line, text[1:])
        buf.end_user_action()

    def _on_comment(self) -> None:
        """Convert the selection into ``[text]: #`` comments, else prompt for one.

        With a selection each selected line is replaced by ``[line]: #``; with
        no selection a prompted ``[text]: #`` is inserted at the cursor.
        """
        selected = self._editor.get_selected_text()

        def on_comment(comment):
            """Handle comment input."""
            if not comment:
                return
            self._insert_block(f"[{comment}]: #")
            self._editor.focus()

        if selected:
            body = selected.strip("\n")
            lines = body.split("\n")
            marked = "\n".join(f"[{ln.strip()}]: #" for ln in lines if ln.strip())
            self._editor.replace_selection(marked + "\n")
            self._editor.focus()
            return
        ask_string(self, "Enter the comment text:", "Comment", on_comment)

    def _on_yaml_front_matter(self) -> None:
        """Open the YAML Front Matter dialog and prepend the metadata block."""

        def callback(block):
            """Handle YAML front matter block."""
            text = self._editor.get_text()
            if text.startswith("---"):
                show_message(
                    self,
                    "YAML Front Matter",
                    "The document already has a YAML Front Matter block.",
                    "warning",
                )
                return
            buf = self._editor.get_buffer()
            start = buf.get_start_iter()
            buf.begin_user_action()
            buf.insert(start, block + "\n\n")
            buf.end_user_action()
            self._editor.focus()

        dlg = YAMLFrontMatterDialog(callback)
        dlg.present()

    def _insert_block(self, text: str) -> None:
        """Insert *text* as a block (with a leading blank line) at the cursor."""
        self._add_blank_line_before_if_needed()
        self._editor.insert_at_cursor(text + "\n")
        self._editor.focus()

    def _on_toggle_theme(self) -> None:
        """Switch between light and dark appearance modes."""
        new = "dark" if self._theme_mode == "light" else "light"
        self._apply_theme(new)

    def _on_editor_font(self) -> None:
        """Open the font chooser to change the editor font family and size."""
        dialog = Gtk.FontDialog()
        dialog.set_title("Choose Editor Font")
        font_desc = Pango.FontDescription.from_string(
            f"Noto Sans Mono {self.editor_font_size}"
        )
        dialog.choose_font(self, font_desc, None, self._on_editor_font_response)

    def _on_editor_font_response(self, dialog, result) -> None:
        """Handle the result of the font chooser dialog."""
        try:
            font_desc = dialog.choose_font_finish(result)
        except GLib.Error:
            return
        if font_desc:
            family = font_desc.get_family()
            size = font_desc.get_size()
            if size > 0:
                self.editor_font_size = size // Pango.SCALE
            self._editor_font_family = family
            self._editor.set_font_family(family)
            self._editor.set_font_size(self.editor_font_size)
            save_font(family, self.editor_font_size)

    def _apply_theme(self, name: str) -> None:
        """Apply the named theme ('light' or 'dark') and persist the choice."""
        name = name.lower()
        if name not in THEMES:
            return
        settings = Gtk.Settings.get_default()
        if name == "dark":
            settings.set_property("gtk-application-prefer-dark-theme", True)
            self._status_label.add_css_class("dark")
        else:
            settings.set_property("gtk-application-prefer-dark-theme", False)
            self._status_label.remove_css_class("dark")
        self._theme_mode = name
        self._editor.set_mode(name)
        save_theme(name)

    def _zoom(self, delta: int) -> None:
        """Change the editor font size by *delta* points and persist."""
        self.editor_font_size = max(8, self.editor_font_size + delta)
        self._editor.set_font_size(self.editor_font_size)
        save_font(self._editor_font_family, self.editor_font_size)

    def _on_zoom_in(self) -> None:
        """Increase the editor font size by two points and persist."""
        self._zoom(2)

    def _on_zoom_out(self) -> None:
        """Decrease the editor font size by two points and persist."""
        self._zoom(-2)

    def _on_quick_view(self) -> None:
        """Render the document as styled HTML5 in a quick-view window.

        A temp HTML file is generated, then opened in a new GTK4/WebKit
        window.  The temp HTML is rewritten on every quick view and deleted
        when the quick-view window closes.
        """
        content = self._editor.get_text()
        if self.current_file:
            save_temp_md(content, self.current_file)
        try:
            html = md_to_html(content)
            html_path = save_temp_html(html, self.current_file)
        except Exception as exc:
            show_message(self, "Quick View", str(exc), "error")
            return

        from mark_editor.viewer import QuickViewWindow

        window = QuickViewWindow(
            html_path.as_uri(), title="Quick View", html_path=html_path
        )
        self._quick_view_windows.append(window)
        window.connect("close-request", self._on_quick_view_window_closed)
        window.connect("destroy", self._on_quick_view_window_closed)

    def _on_help_markdown_guide(self) -> None:
        """Open the Markdown Guide website in the default browser."""
        webbrowser.open("https://www.markdownguide.org/")

    def _on_help_md_ref(self) -> None:
        """Download the Full Markdown Functionality Reference into the editor."""
        self._download_and_open("assets/docs/markdown2html5-base.md", "Reference")

    def _download_and_open(self, file_name: str, label: str) -> None:
        """Fetch *file_name* from the mark_editor repo and open it in the editor.

        The file is downloaded into ``~/.cache/mark_editor`` and opened in the
        current window.
        """
        cache = ensure_cache_dir()
        candidates = list(dict.fromkeys((file_name, file_name.rsplit("/", 1)[-1])))
        text = None
        last_error: Exception | None = None
        for candidate in candidates:
            try:
                req = urllib.request.Request(
                    "https://raw.githubusercontent.com/nobus-1967/mark_editor"
                    f"/main/{candidate}",
                    headers={"User-Agent": f"MarkEditor/{VERSION}"},
                )
                with urllib.request.urlopen(req, timeout=30) as resp:
                    text = resp.read().decode("utf-8")
                break
            except Exception as exc:
                last_error = exc
        if text is None:
            show_message(self, label, str(last_error), "error")
            return
        path = cache / file_name.rsplit("/", 1)[-1]
        path.write_text(text, encoding="utf-8")
        self.load_file(path)

    def _on_help_cheatsheet(self) -> None:
        """Download the keyboard-shortcuts cheat sheet into the editor."""
        self._download_and_open("assets/docs/cheatsheet.md", "Cheat Sheet")

    def _on_help_about(self) -> None:
        """Show the About dialog with version and release information."""
        dlg = AboutDialog(APP_NAME, VERSION, RELEASE)
        dlg.present()

    def _restore_pending_text(self) -> None:
        """Restore any unsaved text from the previous session (cached temp file)."""
        text = load_temp_md(None)
        if text and text.strip():
            self._editor.set_text(text)
            self.is_modified = True
            self._update_title()
