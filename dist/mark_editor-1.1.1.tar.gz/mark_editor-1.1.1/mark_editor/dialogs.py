"""Dialog classes for Mark Editor (GTK4 / libadwaita)."""

from __future__ import annotations

import re
from datetime import datetime

import gi

gi.require_version("Adw", "1")

from gi.repository import Adw, Gtk

from mark_editor.constants import LANGUAGE_TAGS


def _make_dialog_box(spacing: int = 8) -> Gtk.Box:
    """Create a vertical dialog content box with standard margins."""
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=spacing)
    box.set_margin_top(24)
    box.set_margin_bottom(24)
    box.set_margin_start(24)
    box.set_margin_end(24)
    return box


def _make_dropdown_row(
    options: tuple[str, ...] | list[str] | None,
    entry: Gtk.Entry,
) -> Gtk.DropDown | None:
    """Create a drop-down that fills ``entry`` with the selected option.

    The default selection is ``en`` (or the first option if ``en`` is absent).
    Returns ``None`` when ``options`` is empty so callers can skip the widget.
    """
    if not options:
        return None
    combo = Gtk.DropDown.new(Gtk.StringList.new(list(options)))
    default_idx = list(options).index("en") if "en" in options else 0
    combo.set_selected(default_idx)

    def on_combo(_combo, *_args):
        """Fill the entry with the selected option."""
        selected = _combo.get_selected_item()
        if selected is not None:
            entry.set_text(selected.get_string())

    combo.connect("notify::selected-item", on_combo)
    return combo


def _dropdown_value(combo: Gtk.DropDown | None, entry_text: str) -> str | None:
    """Return the entry text, falling back to the combo's selected option."""
    text = entry_text.strip()
    if not text and combo is not None:
        selected = combo.get_selected_item()
        if selected is not None:
            text = selected.get_string()
    return text or None


def _compile_pattern(term: str, use_regex: bool) -> re.Pattern | None:
    """Compile *term* into a regex pattern, or return None (empty/invalid)."""
    if not term:
        return None
    try:
        return re.compile(term if use_regex else re.escape(term))
    except re.error:
        return None


def _find_and_select(editor, pattern: re.Pattern) -> bool:
    """Select the next occurrence of *pattern* from the cursor.

    Wraps around to the start of the document when the pattern is not found
    ahead of the cursor. Returns True when a match was selected.
    """
    text = editor.get_text()
    offset = editor.get_cursor_iter().get_offset()
    match = pattern.search(text, offset) or pattern.search(text)
    if match is None:
        return False
    buf = editor.get_buffer()
    buf.select_range(
        buf.get_iter_at_offset(match.start()),
        buf.get_iter_at_offset(match.end()),
    )
    editor.scroll_to_cursor()
    return True


def _make_insert_cancel_box(dialog) -> Gtk.Box:
    """Build an Insert/Cancel button box for a dialog with an ``_on_insert``."""
    insert_btn = _make_button("Insert", dialog._on_insert, suggested=True)
    cancel_btn = _make_button("Cancel", lambda _: dialog.close())
    return _make_button_box(insert_btn, cancel_btn)


def _make_button_box(*buttons: Gtk.Button) -> Gtk.Box:
    """Create a horizontally centered box containing the given buttons."""
    box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
    box.set_halign(Gtk.Align.CENTER)
    box.set_margin_top(12)
    for btn in buttons:
        box.append(btn)
    return box


def _make_button(label: str, callback=None, suggested: bool = False) -> Gtk.Button:
    """Create a button with an optional click callback and suggested-action style."""
    btn = Gtk.Button(label=label)
    if suggested:
        btn.add_css_class("suggested-action")
    if callback:
        btn.connect("clicked", callback)
    return btn


def _make_grid(
    *rows: tuple[str, Gtk.Widget], col_spacing: int = 8, row_spacing: int = 8
) -> Gtk.Grid:
    """Build a two-column grid from (label, widget) pairs."""
    grid = Gtk.Grid()
    grid.set_column_spacing(col_spacing)
    grid.set_row_spacing(row_spacing)
    for i, (label_text, widget) in enumerate(rows):
        lbl = Gtk.Label(label=label_text)
        lbl.set_xalign(1.0)
        grid.attach(lbl, 0, i, 1, 1)
        grid.attach(widget, 1, i, 1, 1)
    return grid


def show_message(
    parent: Gtk.Window, title: str, message: str, icon: str = "info"
) -> None:
    """Display an alert dialog with an *icon* role (info, warning or error)."""
    alert = Adw.AlertDialog()
    alert.set_heading(title)
    alert.set_body(message)
    alert.add_response("ok", "_OK")
    if icon == "error":
        alert.set_response_appearance("ok", Adw.ResponseAppearance.DESTRUCTIVE)
    elif icon == "warning":
        alert.set_response_appearance("ok", Adw.ResponseAppearance.SUGGESTED)
    alert.present(parent)


def ask_string(
    parent: Gtk.Window,
    prompt: str,
    title: str,
    callback=None,
    options: tuple[str, ...] | list[str] | None = None,
) -> None:
    """Show a dialog that prompts the user for a single text input.

    If ``options`` is given, it is shown as a combo box (drop-down) above the entry;
    selecting an option fills the entry. The entry remains editable so a custom
    BCP 47 tag can be typed.
    """
    dialog = Adw.Dialog()
    dialog.set_title(title)
    dialog.set_content_width(400)
    box = _make_dialog_box(spacing=12)

    entry = Gtk.Entry()
    entry.set_hexpand(True)

    combo = None
    if options:
        combo_lbl = Gtk.Label(label="Choose a language tag:")
        combo_lbl.set_xalign(0.0)
        box.append(combo_lbl)

        combo = _make_dropdown_row(options, entry)
        if combo is not None:
            box.append(combo)

    lbl = Gtk.Label(label=prompt)
    lbl.set_xalign(0.0)
    box.append(lbl)

    box.append(entry)

    result_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
    result_box.set_halign(Gtk.Align.END)
    result_box.set_margin_top(8)

    cancel_btn = _make_button("Cancel")
    cancel_btn.connect("clicked", lambda _: dialog.close())
    result_box.append(cancel_btn)

    ok_btn = _make_button("OK", suggested=True)
    result_box.append(ok_btn)
    box.append(result_box)

    def on_ok(_btn):
        """Handle OK button click."""
        text = _dropdown_value(combo, entry.get_text())
        dialog.close()
        if callback:
            callback(text)

    ok_btn.connect("clicked", on_ok)
    entry.connect("activate", lambda _: on_ok(_))

    dialog.set_child(box)
    dialog.present(parent)


class FindDialog(Adw.Dialog):
    """Dialog for searching text within the editor."""

    def __init__(self, editor) -> None:
        """Initialize the Find dialog with a reference to the editor."""
        super().__init__()
        self.set_title("Find")
        self.set_content_width(420)

        self._editor = editor
        self._use_regex = False

        box = _make_dialog_box()

        self._entry = Gtk.Entry()
        self._entry.set_hexpand(True)
        self._entry.set_placeholder_text("Search text...")
        grid = _make_grid(("Find:", self._entry))
        box.append(grid)

        self._regex_check = Gtk.CheckButton(label="Use regex")
        self._regex_check.connect(
            "toggled", lambda b: setattr(self, "_use_regex", b.get_active())
        )
        box.append(self._regex_check)

        find_btn = _make_button("Find Next", self._on_find_next, suggested=True)
        close_btn = _make_button("Close", lambda _: self.close())
        box.append(_make_button_box(find_btn, close_btn))

        self._entry.connect("activate", lambda _: self._on_find_next())
        self._entry.connect("changed", self._on_search_changed)
        self.set_child(box)
        self._entry.grab_focus()

    def _on_find_next(self, *_args) -> None:
        """Find and select the next occurrence of the search term."""
        pattern = _compile_pattern(self._entry.get_text().strip(), self._use_regex)
        if pattern is not None:
            _find_and_select(self._editor, pattern)

    def _on_search_changed(self, entry) -> None:
        """Update the editor's search highlights as the user types."""
        term = entry.get_text().strip()
        self._editor.set_search_pattern(term, case_sensitive=False)

    def close(self) -> None:
        """Clear search highlights and close the dialog."""
        self._editor.clear_search()
        super().close()


class ReplaceDialog(Adw.Dialog):
    """Dialog for finding and replacing text in the editor."""

    def __init__(self, editor) -> None:
        """Initialize the Replace dialog with a reference to the editor."""
        super().__init__()
        self.set_title("Replace")
        self.set_content_width(420)

        self._editor = editor
        self._use_regex = False

        box = _make_dialog_box()

        self._find_entry = Gtk.Entry()
        self._find_entry.set_hexpand(True)
        self._replace_entry = Gtk.Entry()
        self._replace_entry.set_hexpand(True)

        grid = _make_grid(
            ("Find:", self._find_entry),
            ("Replace:", self._replace_entry),
        )
        box.append(grid)

        self._regex_check = Gtk.CheckButton(label="Use regex")
        self._regex_check.connect(
            "toggled", lambda b: setattr(self, "_use_regex", b.get_active())
        )
        box.append(self._regex_check)

        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        btn_box.set_halign(Gtk.Align.CENTER)
        btn_box.set_margin_top(12)
        for label, cb in [
            ("Replace", self._on_replace),
            ("Replace All", self._on_replace_all),
            ("Find Next", self._on_find_next),
        ]:
            btn_box.append(_make_button(label, cb))
        btn_box.append(_make_button("Close", lambda _: self.close()))
        box.append(btn_box)

        self._find_entry.connect("activate", lambda _: self._on_find_next())
        self._find_entry.connect("changed", self._on_search_changed)
        self.set_child(box)
        self._find_entry.grab_focus()

    def _get_pattern(self) -> re.Pattern | None:
        """Compile the find entry text into a regex pattern, or return None."""
        return _compile_pattern(self._find_entry.get_text(), self._use_regex)

    def _on_find_next(self, *_args) -> None:
        """Find and select the next match of the search pattern."""
        pattern = self._get_pattern()
        if pattern is None:
            return
        _find_and_select(self._editor, pattern)

    def _on_replace(self, *_args) -> None:
        """Find the next match from the cursor, then replace it."""
        pattern = self._get_pattern()
        if pattern is None:
            return
        if not _find_and_select(self._editor, pattern):
            return
        buf = self._editor.get_buffer()
        start, end = buf.get_selection_bounds()
        buf.begin_user_action()
        buf.delete(start, end)
        buf.insert(start, self._replace_entry.get_text(), -1)
        buf.end_user_action()

    def _on_replace_all(self, *_args) -> None:
        """Replace every occurrence of the search text in the buffer."""
        find_text = self._find_entry.get_text()
        replace_text = self._replace_entry.get_text()
        if not find_text:
            return
        self._editor.replace_all(find_text, replace_text, self._use_regex)

    def _on_search_changed(self, entry) -> None:
        """Update the editor's search highlights as the user types."""
        term = entry.get_text().strip()
        self._editor.set_search_pattern(term, case_sensitive=False)

    def close(self) -> None:
        """Clear search highlights and close the dialog."""
        self._editor.clear_search()
        super().close()


class TableDialog(Adw.Dialog):
    """Dialog for inserting a Markdown table."""

    def __init__(self, callback) -> None:
        """Initialize the Table dialog with a result callback."""
        super().__init__()
        self.set_title("Insert Table")
        self.set_content_width(380)

        self._callback = callback

        box = _make_dialog_box()

        self._cols_spin = Gtk.SpinButton.new_with_range(1, 20, 1)
        self._cols_spin.set_value(3)
        self._rows_spin = Gtk.SpinButton.new_with_range(1, 50, 1)
        self._rows_spin.set_value(3)

        box.append(
            _make_grid(("Columns:", self._cols_spin), ("Rows:", self._rows_spin))
        )

        self._footer_check = Gtk.CheckButton(label="Add footer")
        self._footer_check.set_active(True)
        box.append(self._footer_check)

        box.append(_make_insert_cancel_box(self))
        self.set_child(box)

    def _on_insert(self, *_args) -> None:
        """Build the Markdown table string and invoke the callback."""
        cols = int(self._cols_spin.get_value())
        rows = int(self._rows_spin.get_value())
        use_footer = self._footer_check.get_active()

        header = "| " + " | ".join(["Header"] * cols) + " |"
        align = "| " + " | ".join(["---"] * cols) + " |"
        lines = ["", header, align]
        for _ in range(rows):
            lines.append("| " + " | ".join(["Cell"] * cols) + " |")
        if use_footer:
            lines.append("| " + " | ".join(["==="] * cols) + " |")
            lines.append("| " + " | ".join(["Footer"] * cols) + " |")
        self._callback("\n".join(lines))
        self.close()


class TableAlignDialog(Adw.Dialog):
    """Dialog for choosing a Markdown table alignment marker."""

    ALIGN_OPTIONS = (
        "none",
        "left",
        "center",
        "right",
    )
    ALIGN_VALUES = ("---", ":---", ":---:", "---:")

    def __init__(self, callback) -> None:
        """Initialize the dialog; *callback(marker)* runs on a valid choice."""
        super().__init__()
        self.set_title("Table Alignment")
        self.set_content_width(320)

        self._callback = callback

        box = _make_dialog_box()

        lbl = Gtk.Label(label="Select alignment:")
        lbl.set_xalign(0.0)
        box.append(lbl)

        self._align = Gtk.DropDown.new_from_strings(list(self.ALIGN_OPTIONS))
        self._align.set_selected(0)
        box.append(self._align)

        ok_btn = _make_button("OK", self._on_ok, suggested=True)
        cancel_btn = _make_button("Cancel", lambda _: self.close())
        box.append(_make_button_box(ok_btn, cancel_btn))

        self.set_child(box)

    def _on_ok(self, *_args) -> None:
        """Signal *callback* with the chosen alignment marker and close."""
        self.close()
        self._callback(self.ALIGN_VALUES[self._align.get_selected()])


class TableRowDialog(Adw.Dialog):
    """Dialog for picking the number of cells in a new table row."""

    def __init__(self, callback) -> None:
        """Initialize the dialog; *callback(count)* runs on a valid count."""
        super().__init__()
        self.set_title("Add Table Row")
        self.set_content_width(360)

        self._callback = callback

        box = _make_dialog_box()

        lbl = Gtk.Label(label="Choose the number of cells:")
        lbl.set_xalign(0.0)
        box.append(lbl)

        self._spin = Gtk.SpinButton.new_with_range(1, 9, 1)
        self._spin.set_value(3)
        box.append(self._spin)

        box.append(_make_insert_cancel_box(self))
        self.set_child(box)

    def _on_insert(self, *_args) -> None:
        """Signal *callback* with the chosen number of cells and close."""
        self.close()
        self._callback(int(self._spin.get_value()))


class TodoListDialog(Adw.Dialog):
    """Dialog for adding/updating the ``[ ]``/``[x]`` marker, optionally checked."""

    def __init__(self, callback) -> None:
        """Initialize the dialog; *callback(checked)* runs on insert."""
        super().__init__()
        self.set_title("Todo List")
        self.set_content_width(360)

        self._callback = callback

        box = _make_dialog_box()

        lbl = Gtk.Label(
            label="Add/update the todo marker ([ ]/[x]) on the current line:"
        )
        lbl.set_xalign(0.0)
        box.append(lbl)

        self._checked = Gtk.CheckButton(label="Checked (Completed)")
        box.append(self._checked)

        box.append(_make_insert_cancel_box(self))
        self.set_child(box)

    def _on_insert(self, *_args) -> None:
        """Signal *callback* with the checked state and close."""
        checked = self._checked.get_active()
        self.close()
        self._callback(checked)


class FuriganaDialog(Adw.Dialog):
    """Dialog for adding a furigana (ruby) annotation."""

    def __init__(self, editor) -> None:
        """Initialize the dialog; *editor* receives the ruby annotation."""
        super().__init__()
        self.set_title("Furigana (Ruby Annotation)")
        self.set_content_width(380)

        self._editor = editor

        box = _make_dialog_box()

        self._kanji_entry = Gtk.Entry()
        self._kanji_entry.set_hexpand(True)
        self._reading_entry = Gtk.Entry()
        self._reading_entry.set_hexpand(True)

        box.append(
            _make_grid(
                ("Kanji / Text:", self._kanji_entry),
                ("Reading (ruby):", self._reading_entry),
            )
        )

        box.append(_make_insert_cancel_box(self))

        self._kanji_entry.connect("activate", lambda _: self._on_insert())
        self._reading_entry.connect("activate", lambda _: self._on_insert())
        self.set_child(box)

        selected = self._editor.get_selected_text()
        if selected:
            self._kanji_entry.set_text(selected)
            self._kanji_entry.select_region(0, -1)
            self._reading_entry.grab_focus()
        else:
            self._kanji_entry.grab_focus()

    def _on_insert(self, *_args) -> None:
        """Wrap the selected kana (or the entered text) in a ruby annotation."""
        reading = self._reading_entry.get_text().strip()
        selected = self._editor.get_selected_text()
        kanji = selected or self._kanji_entry.get_text().strip()
        if kanji and reading:
            self._editor.replace_selection(f"{{{kanji}|{reading}}}")
        self.close()


class OrderedListDialog(Adw.Dialog):
    """Dialog for picking an ordered-list item number."""

    def __init__(self, callback) -> None:
        """Initialize the dialog; *callback(number)* runs on a valid number."""
        super().__init__()
        self.set_title("Ordered List")
        self.set_content_width(360)

        self._callback = callback

        box = _make_dialog_box()

        lbl = Gtk.Label(label="Insert item's number:")
        lbl.set_xalign(0.0)
        box.append(lbl)

        self._spin = Gtk.SpinButton.new_with_range(1, 999, 1)
        self._spin.set_value(1)

        box.append(self._spin)

        box.append(_make_insert_cancel_box(self))

        self._spin.connect("activate", lambda _: self._on_insert())
        self.set_child(box)
        self._spin.grab_focus()

    def _on_insert(self, *_args) -> None:
        """Signal the *callback* with the chosen number and close."""
        self.close()
        self._callback(int(self._spin.get_value()))


class HeaderLinkDialog(Adw.Dialog):
    """Dialog for inserting a cross-reference link to a document heading."""

    def __init__(self, callback) -> None:
        """Initialize the Header Link dialog with a result callback."""
        super().__init__()
        self.set_title("Insert Header Link")
        self.set_content_width(380)

        self._callback = callback

        box = _make_dialog_box()

        self._id_entry = Gtk.Entry()
        self._id_entry.set_hexpand(True)
        self._text_entry = Gtk.Entry()
        self._text_entry.set_hexpand(True)

        box.append(
            _make_grid(
                ("Header ID:", self._id_entry),
                ("Link text:", self._text_entry),
            )
        )

        box.append(_make_insert_cancel_box(self))

        self._id_entry.connect("activate", lambda _: self._on_insert())
        self._text_entry.connect("activate", lambda _: self._on_insert())
        self.set_child(box)
        self._id_entry.grab_focus()

    def _on_insert(self, *_args) -> None:
        """Build the heading link and invoke the callback."""
        hid = self._id_entry.get_text().strip()
        text = self._text_entry.get_text().strip() or hid
        if hid:
            self._callback(f"[{text}](#{hid})")
        self.close()


class TOCDialog(Adw.Dialog):
    """Dialog for table-of-contents operations.

    Operations: add the TOC, add header IDs only, regenerate (remove and
    generate again), or remove the existing table of contents.
    """

    TOC_OPTIONS = (
        "Add TOC",
        "Regenerate existing TOC",
        "Remove existing TOC",
        "Add Header IDs only",
    )

    def __init__(self, callback) -> None:
        """Initialize the Table of Contents dialog with a result callback."""
        super().__init__()
        self.set_title("Table of Contents")
        self.set_content_width(380)

        self._callback = callback

        box = _make_dialog_box()

        prompt = Gtk.Label(label="Select an operation:")
        prompt.set_halign(Gtk.Align.START)
        box.append(prompt)

        self._ops = Gtk.DropDown.new_from_strings(list(self.TOC_OPTIONS))
        self._ops.set_halign(Gtk.Align.START)
        self._ops.set_selected(0)
        box.append(self._ops)

        heading_label = Gtk.Label(label="TOC heading:")
        heading_label.set_halign(Gtk.Align.START)
        box.append(heading_label)

        self._title_entry = Gtk.Entry()
        self._title_entry.set_hexpand(True)
        self._title_entry.set_text("Table of Contents")
        box.append(self._title_entry)

        ok_btn = _make_button("OK", self._on_ok, suggested=True)
        cancel_btn = _make_button("Cancel", lambda _: self.close())
        box.append(_make_button_box(ok_btn, cancel_btn))

        self.set_child(box)

    def _on_ok(self, *_args) -> None:
        """Signal the *callback* with the operation index and heading, and close."""
        self.close()
        self._callback(self._ops.get_selected(), self._title_entry.get_text().strip())


class FootnoteDialog(Adw.Dialog):
    """Dialog for inserting a footnote reference and optional definition."""

    def __init__(self, callback) -> None:
        """Initialize the Footnote dialog with a result callback."""
        super().__init__()
        self.set_title("Insert Footnote")
        self.set_content_width(380)

        self._callback = callback

        box = _make_dialog_box()

        self._ref_entry = Gtk.Entry()
        self._ref_entry.set_hexpand(True)
        self._def_entry = Gtk.Entry()
        self._def_entry.set_hexpand(True)

        box.append(
            _make_grid(
                ("Reference / Name:", self._ref_entry),
                ("Definition:", self._def_entry),
            )
        )

        box.append(_make_insert_cancel_box(self))

        self._ref_entry.connect("activate", lambda _: self._on_insert())
        self.set_child(box)
        self._ref_entry.grab_focus()

    def _on_insert(self, *_args) -> None:
        """Insert the footnote reference and optional definition."""
        ref = self._ref_entry.get_text().strip()
        definition = self._def_entry.get_text().strip()
        if ref:
            self._callback(ref, definition)
        self.close()


class DefinitionListDialog(Adw.Dialog):
    """Dialog for inserting a Markdown definition-list block."""

    def __init__(self, callback) -> None:
        """Initialize the Definition List dialog with a result callback."""
        super().__init__()
        self.set_title("Definition List")
        self.set_content_width(400)

        self._callback = callback

        box = _make_dialog_box()

        self._term_entry = Gtk.Entry()
        self._term_entry.set_hexpand(True)
        self._defs_spin = Gtk.SpinButton.new_with_range(1, 9, 1)
        self._defs_spin.set_value(1)

        box.append(
            _make_grid(("Term:", self._term_entry), ("Definitions:", self._defs_spin))
        )

        box.append(_make_insert_cancel_box(self))
        self.set_child(box)
        self._term_entry.grab_focus()

    def _on_insert(self, *_args) -> None:
        """Build the definition-list block and invoke the callback."""
        term = self._term_entry.get_text().strip()
        count = int(self._defs_spin.get_value())
        if term:
            lines = ["", term]
            lines.extend(f": Definition {i}" for i in range(1, count + 1))
            self._callback("\n".join(lines))
        self.close()


class YAMLFrontMatterDialog(Adw.Dialog):
    """Dialog for inserting a YAML front-matter metadata block."""

    def __init__(self, callback) -> None:
        """Initialize the YAML Front Matter dialog with a result callback."""
        super().__init__()
        self.set_title("YAML Front Matter")
        self.set_content_width(420)

        self._callback = callback

        fields = ["lang", "title", "author", "description", "keywords"]
        self._entries: dict[str, Gtk.Entry] = {}

        box = _make_dialog_box()

        grid = Gtk.Grid()
        grid.set_column_spacing(8)
        grid.set_row_spacing(8)
        self._lang_combo: Gtk.DropDown | None = None
        for i, field in enumerate(fields):
            lbl = Gtk.Label(label=f"{field}:")
            lbl.set_xalign(1.0)
            entry = Gtk.Entry()
            entry.set_hexpand(True)
            self._entries[field] = entry
            if field == "lang":
                vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
                self._lang_combo = _make_dropdown_row(LANGUAGE_TAGS, entry)
                if self._lang_combo is not None:
                    vbox.append(self._lang_combo)
                vbox.append(entry)
                grid.attach(lbl, 0, i, 1, 1)
                grid.attach(vbox, 1, i, 1, 1)
                continue
            grid.attach(lbl, 0, i, 1, 1)
            grid.attach(entry, 1, i, 1, 1)
        box.append(grid)

        box.append(_make_insert_cancel_box(self))
        self.set_child(box)

    def _on_insert(self, *_args) -> None:
        """Build the YAML block from filled fields and invoke the callback."""
        lines = ["---"]
        for field in ["lang", "title", "author", "description", "keywords"]:
            value = self._entries[field].get_text().strip()
            if not value and field == "lang":
                value = _dropdown_value(self._lang_combo, "") or ""
            if value:
                lines.append(f"{field}: {value}")
        lines.append(f"published: {datetime.now().date().isoformat()}")
        lines.append("---")
        self._callback("\n".join(lines))
        self.close()


class DateTimeDialog(Adw.Dialog):
    """Dialog for inserting a formatted date and/or time stamp."""

    def __init__(self, callback) -> None:
        """Initialize the Date & Time dialog with a result callback."""
        super().__init__()
        self.set_title("Insert Date and Time")
        self.set_content_width(320)

        self._callback = callback
        self._choice = "date_time"

        box = _make_dialog_box()

        group = Gtk.CheckButton()
        for label, value in [
            ("Date and time", "date_time"),
            ("Date only", "date"),
            ("Time only", "time"),
        ]:
            btn = Gtk.CheckButton(label=label, group=group)
            btn.set_active(value == "date_time")
            btn.connect(
                "toggled",
                lambda b, v=value: (
                    setattr(self, "_choice", v) if b.get_active() else None
                ),
            )
            box.append(btn)

        box.append(_make_insert_cancel_box(self))
        self.set_child(box)

    def _on_insert(self, *_args) -> None:
        """Format the current date/time selection and invoke the callback."""
        now = datetime.now()
        if self._choice == "date_time":
            value = now.strftime("%Y-%m-%d %H:%M:%S")
        elif self._choice == "date":
            value = now.strftime("%Y-%m-%d")
        else:
            value = now.strftime("%H:%M:%S")
        self._callback(value)
        self.close()


class ChoiceDialog(Adw.Dialog):
    """Dialog for selecting an item from a drop-down list."""

    def __init__(self, prompt: str, items: list[str], initial: str) -> None:
        """Initialize the Choice dialog with prompt, items, and initial selection."""
        super().__init__()
        self.set_title("Select")
        self.set_content_width(380)

        self.result: str | None = None

        box = _make_dialog_box(spacing=12)

        lbl = Gtk.Label(label=prompt)
        lbl.set_xalign(0.0)
        box.append(lbl)

        self._dropdown = Gtk.DropDown()
        model = Gtk.StringList()
        for item in items:
            model.append(item)
        self._dropdown.set_model(model)
        idx = items.index(initial) if initial in items else 0
        self._dropdown.set_selected(idx)
        box.append(self._dropdown)

        ok_btn = _make_button("OK", self._on_ok, suggested=True)
        cancel_btn = _make_button("Cancel", lambda _: self.close())
        box.append(_make_button_box(ok_btn, cancel_btn))
        self.set_child(box)

    def _on_ok(self, *_args) -> None:
        """Store the selected item and close the dialog."""
        model = self._dropdown.get_model()
        idx = self._dropdown.get_selected()
        if idx is not None and idx < model.get_n_items():
            self.result = model.get_string(idx)
        self.close()


class AboutDialog(Adw.Dialog):
    """Dialog showing application name, version and release information."""

    def __init__(self, app_name: str, version: str, release: str) -> None:
        """Initialize the About dialog with app name, version, and release."""
        super().__init__()
        self.set_title("About")
        self.set_content_width(360)

        box = _make_dialog_box(spacing=12)
        box.set_halign(Gtk.Align.CENTER)

        lbl = Gtk.Label(label=f"{app_name}, version {version} ({release})")
        box.append(lbl)

        close_btn = _make_button("Close", lambda _: self.close())
        close_btn.set_size_request(100, -1)
        box.append(close_btn)

        self.set_child(box)
